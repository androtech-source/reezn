REEZN BROWSER FOR KODI
========================

This package is a Kodi video plugin that provides a Reezn-style browsing
interface using TMDB metadata.

IMPORTANT
---------
This version does NOT extract, bypass, decrypt, or reproduce protected or
unauthorized Reezn streams. It is a safe Kodi frontend/base implementation.

SETUP
-----
1. Install the ZIP in Kodi: Add-ons -> Install from zip file.
2. Enable Unknown sources if Kodi asks.
3. Open Reezn Browser -> Settings.
4. Enter your own TMDB API key.
5. Open the addon and browse Movies / TV Shows / Trending / Search.

PLAYBACK
--------
Details pages can expose YouTube trailers when the official Kodi YouTube
addon is installed. Full Reezn playback requires an authorized/public
playback API or source that can legally be used by a Kodi addon.
