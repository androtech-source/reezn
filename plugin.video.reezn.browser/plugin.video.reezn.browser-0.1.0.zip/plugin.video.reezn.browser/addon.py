# -*- coding: utf-8 -*-
import sys
import json
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = "https://api.themoviedb.org/3"
IMG = "https://image.tmdb.org/t/p/w500"

def setting(name):
    return ADDON.getSetting(name)

def request(path, params=None):
    key = setting("tmdb_api_key").strip()
    if not key:
        xbmcgui.Dialog().ok(
            "Reezn Browser",
            "Add your TMDB API key in Add-ons > My add-ons > Video add-ons > Reezn Browser > Settings."
        )
        return None
    params = dict(params or {})
    params["api_key"] = key
    params["language"] = setting("language") or "en-US"
    url = BASE + path + "?" + urllib.parse.urlencode(params)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Kodi-Reezn-Browser/0.1"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception as e:
        xbmcgui.Dialog().notification("Reezn Browser", "TMDB request failed", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log("Reezn Browser: %s" % e, xbmc.LOGERROR)
        return None

def add_folder(label, route):
    u = sys.argv[0] + "?" + urllib.parse.urlencode({"route": route})
    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(HANDLE, u, li, True)

def add_media(item, media_type):
    title = item.get("title") or item.get("name") or "Unknown"
    date = item.get("release_date") or item.get("first_air_date") or ""
    year = date[:4] if date else ""
    label = title + ((" (" + year + ")") if year else "")
    li = xbmcgui.ListItem(label=label)
    poster = item.get("poster_path")
    backdrop = item.get("backdrop_path")
    if poster:
        li.setArt({"poster": IMG + poster, "thumb": IMG + poster})
    if backdrop:
        li.setArt({"fanart": "https://image.tmdb.org/t/p/w1280" + backdrop})
    info = {
        "title": title,
        "year": int(year) if year.isdigit() else 0,
        "plot": item.get("overview", ""),
        "rating": item.get("vote_average", 0),
    }
    li.setInfo("video", info)
    # No unauthorized stream resolver is included.
    li.setProperty("IsPlayable", "false")
    u = sys.argv[0] + "?" + urllib.parse.urlencode({
        "route": "details",
        "id": item.get("id"),
        "type": media_type
    })
    xbmcplugin.addDirectoryItem(HANDLE, u, li, False)

def details(item_id, media_type):
    data = request("/%s/%s" % (media_type, item_id), {"append_to_response": "videos"})
    if not data:
        return
    title = data.get("title") or data.get("name") or "Title"
    li = xbmcgui.ListItem(label=title)
    li.setArt({
        "poster": IMG + data["poster_path"] if data.get("poster_path") else "",
        "fanart": "https://image.tmdb.org/t/p/w1280" + data["backdrop_path"] if data.get("backdrop_path") else ""
    })
    li.setInfo("video", {
        "title": title,
        "plot": data.get("overview", ""),
        "rating": data.get("vote_average", 0),
        "genre": ", ".join([g["name"] for g in data.get("genres", [])])
    })
    xbmcplugin.addDirectoryItem(HANDLE, "", li, False)

    videos = (data.get("videos") or {}).get("results", [])
    for v in videos:
        if v.get("site") == "YouTube" and v.get("key"):
            trailer = xbmcgui.ListItem(label="▶ " + v.get("name", "Trailer"))
            url = "plugin://plugin.video.youtube/play/?video_id=" + urllib.parse.quote(v["key"])
            trailer.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(HANDLE, url, trailer, False)

def listing(route):
    if route == "movies":
        data = request("/movie/popular", {"page": 1})
        for x in (data or {}).get("results", []):
            add_media(x, "movie")
    elif route == "tv":
        data = request("/tv/popular", {"page": 1})
        for x in (data or {}).get("results", []):
            add_media(x, "tv")
    elif route == "trending":
        data = request("/trending/all/week")
        for x in (data or {}).get("results", []):
            add_media(x, x.get("media_type", "movie"))
    elif route == "search":
        q = xbmcgui.Dialog().input("Search")
        if q:
            data = request("/search/multi", {"query": q, "page": 1, "include_adult": "false"})
            for x in (data or {}).get("results", []):
                if x.get("media_type") in ("movie", "tv"):
                    add_media(x, x["media_type"])
    elif route.startswith("details"):
        pass

def main():
    params = urllib.parse.parse_qs(urllib.parse.urlparse(sys.argv[2]).query)
    route = params.get("route", [""])[0]
    if not route:
        add_folder("🎬 Movies", "movies")
        add_folder("📺 TV Shows", "tv")
        add_folder("🔥 Trending", "trending")
        add_folder("🔎 Search", "search")
    elif route == "search":
        listing("search")
    elif route == "details":
        details(params.get("id", [""])[0], params.get("type", ["movie"])[0])
    else:
        listing(route)
    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    main()
